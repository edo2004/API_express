module.exports = {
  start_class: '1 de noviembre del xxx'
}