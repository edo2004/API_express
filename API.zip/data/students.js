module.exports = [
  {
    id: 1,
    name: 'Eduar Ordoñez',
    semester: 1,
    code: 100614123123,
    email: 'eduarord@unicauca.edu.co',
    celular: '310112233',
    carrer: 'Ingeniería electrnoica y telecomunicaciones',
    password: '123123'
  },
  {
    id: 2,
    name: 'Eduar Ordoñez 2',
    semester: 1,
    code: 100614123123,
    email: 'eduarord2@unicauca.edu.co',
    celular: '310112233',
    carrer: 'Ingeniería electrnoica y telecomunicaciones',
    password: '123123'
  }
]